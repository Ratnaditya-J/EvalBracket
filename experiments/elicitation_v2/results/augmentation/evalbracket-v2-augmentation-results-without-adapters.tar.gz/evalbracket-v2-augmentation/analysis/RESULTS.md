# EvalBracket campaign results

This report is generated from frozen configuration and item-level GPU outputs.
The tasks are benign proxies and do not measure dangerous capabilities.

## Primary-threshold sample

* Retained-capability hidden positives: 14
* Induced-capability hidden positives, secondary only: 1
* Failed or statistically ambiguous controls: 30
* Genuine negatives: 2

## Decision performance

Rates are point estimates with a 95 percent cluster-bootstrap interval over model-task pairs.

| Battery | Procedure | False below on hidden positives | Correct below on genuine negatives |
|---|---|---:|---:|
| api_prompt_search | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| api_prompt_search | unqualified elicitation | 35.7% [14.3%, 63.6%] | 100.0% [100.0%, 100.0%] |
| api_prompt_search | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| weight_sft_small | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_small | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_small | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| weight_sft_medium | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_medium | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_medium | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| weight_sft_large | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_large | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_large | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| weight_sft_declared_maximum | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_declared_maximum | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| weight_sft_declared_maximum | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| v2_union_small | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_small | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_small | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| v2_union_medium | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_medium | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_medium | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| v2_union_large | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_large | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_large | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |
| v2_union_declared_maximum | default evaluation | 100.0% [100.0%, 100.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_declared_maximum | unqualified elicitation | 0.0% [0.0%, 0.0%] | 100.0% [100.0%, 100.0%] |
| v2_union_declared_maximum | EvalBracket | 0.0% [0.0%, 0.0%] | 0.0% [0.0%, 0.0%] |

## Capability creation under weight adaptation

These are genuine-negative checkpoints that became verified at or above the threshold after
direct adaptation. They are false positives only for a claim about capability latent in the
original checkpoint. For an open-weight release, they are evidence about adaptation-reachable
capability.

| Adaptation budget | Crossing rate |
|---|---:|
| weight_32 | 0.0% [0.0%, 0.0%] |
| weight_128 | 0.0% [0.0%, 0.0%] |
| weight_256 | 0.0% [0.0%, 0.0%] |
| weight_512 | 0.0% [0.0%, 0.0%] |

## Compute

Completed jobs: 3. Sum of per-job wall time: 1.22 hours.
Provider billing and pod idle time are recorded separately in the campaign manifest.

See `analysis_summary.json`, `organisms.csv`, `decisions.csv`, and `qualifications.csv`
for the full numerical record.
